# Clase 6
## Background
- background-color
- background-image
- background-repeat
- background-position
- background-attachment
- background-size
- background (atajo)

## Fonts
- genéricas
- web 
- locales

## íconos
fontawesome
